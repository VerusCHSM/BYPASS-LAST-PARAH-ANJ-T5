local MtpPackTable = class({}, Assets.req("Scripts.ConfigTable.Base.MtpPackTableBase"))

--------------------------------------------自动生成--------------------------------------------

return MtpPackTable